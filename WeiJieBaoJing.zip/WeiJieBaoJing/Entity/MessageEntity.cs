﻿using FSI.DeviceSDK;
using FSI.DeviceSDK.FiberDefenderDevice;
using FSI.DeviceSDK.Input;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeiJieBaoJing.Entity
{
    public class MessageBase
    {
        protected const string sender = "FiberDefender";
        protected const string receiver = "AMS";
        public Head meta { get; set; }
        public MessageBase()
        {
            meta = new Entity.MessageBase.Head();
        }
        public class Head
        {
            public string sender { get; set; }
            public string msgType { get; set; }
            public string eventType { get; set; }
            public string receiver { get; set; }
            public string sequence { get; set; }
            public string recvSequence { get; set; }
            public string sendTime { get; set; }
            public string recvTime { get; set; }
        }
    }

    public class MessageDevice : MessageBase
    {
        const string equClassCode = "EC06";
        const string equClassName = "围界";
        public MessageDevice(IFiberDefenderAPUDevice device)
        {
            meta.sender = sender;
            meta.msgType = "EQU";
            meta.eventType = "EQU_INFO_UE";
            meta.receiver = receiver;
            meta.sequence = "";
            meta.recvSequence = "";
            meta.sendTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            meta.recvTime = "";
            body = new Entity.MessageDevice.Body();
            body.areaId = "";
            body.areaName = "";
            body.attachDeptId="";
            body.attachDeptName = "";
            body.equClassCode = equClassCode;
            body.equClassName = equClassName;
            body.equCode = "";
            body.equDetail = device.Description;
            body.equIp = device.IPAddress.ToString();
            body.equName = device.Name;
            body.equSystemCode = "";
            body.equSystemName = "";
            body.equTypeCode = "";
            body.equTypeName = "";
            body.floorCode = "";
            body.floorName = "";
            body.gisX = "";
            body.gisY = "";
            body.gisZ = "";
            body.managerDeptId = "";
            body.managerDeptName = "";
            body.operation = "";
            body.timeStateId = "";
            body.timeStateName = "";
        }
        public MessageDevice(IGeneralDevice subDevice)
        {
            meta.sender = sender;
            meta.msgType = "Device";
            meta.eventType = "Device";
            body = new Entity.MessageDevice.Body();
            body.areaId = "";
            body.areaName = "";
            body.attachDeptId = "";
            body.attachDeptName = "";
            body.equClassCode = "";
            body.equClassName = "";
            body.equCode = subDevice.Name;
            body.equDetail = subDevice.Description;
            body.equIp = "";
            body.equName = subDevice.Name;
            body.equSystemCode = "";
            body.equSystemName = "";
            body.equTypeCode = "";
            body.equTypeName = "";
            body.floorCode = "";
            body.floorName = "";
            body.gisX = "";
            body.gisY = "";
            body.gisZ = "";
            body.managerDeptId = "";
            body.managerDeptName = "";
            body.operation = "";
            body.timeStateId = "";
            body.timeStateName = "";
        }

        public Body body { get; set; }

        public class Body
        {
            public string equCode { get; set; }
            public string equName { get; set; }
            public string equClassCode { get; set; }
            public string equClassName { get; set; }
            public string equTypeCode { get; set; }
            public string equTypeName { get; set; }
            public string equIp { get; set; }
            public string equSystemCode { get; set; }
            public string equSystemName { get; set; }
            public string equDetail { get; set; }
            public string attachDeptId { get; set; }
            public string attachDeptName { get; set; }
            public string managerDeptId { get; set; }
            public string managerDeptName { get; set; }
            public string areaId { get; set; }
            public string areaName { get; set; }
            public string gisX { get; set; }
            public string gisY { get; set; }
            public string gisZ { get; set; }
            public string floorCode { get; set; }
            public string floorName { get; set; }
            public string timeStateId { get; set; }
            public string timeStateName { get; set; }
            public string operation { get; set; }
        }

        public string toJson()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    public class MessageAlarm : MessageBase
    {
        const string alarmClassCode = "AC05";
        const string alarmClassName = "围界报警";
        const string alarmTypeCode = "01";
        const string alarmTypeName = "围界报警新事件";
        public MessageAlarm(FSI.DeviceSDK.Input.AlarmEventArgs alarm,string eventType)
        {
            meta.sender = sender;
            meta.msgType = "ALARM";
            meta.eventType = eventType;
            meta.receiver = receiver;
            meta.sequence = "";
            meta.recvSequence = "";
            meta.sendTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            meta.recvTime = "";
            body = new Entity.MessageAlarm.Body();
            body.alarmAddress = "";
            body.alarmClassCode = alarmClassCode;
            body.alarmClassName = alarmClassName;
            body.alarmCode = "";
            body.alarmDescibe = "";
            body.alarmEquId = alarm.Device.Name;
            body.alarmEquName = alarm.Device.Name;
            body.alarmLevelCode = "";
            body.alarmLevelName = "";
            body.alarmName = "";
            body.alarmSource = "";
            body.alarmStateCode = "";
            body.alarmStateName = "";
            body.alarmTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");// alarm.Time.ToString("yyyy-MM-dd HH:mm:ss");
            body.alarmTypeCode = alarmTypeCode;
            body.alarmTypeName = alarmTypeName;
            body.areaName = "";
            body.equClassCode = "";
            body.equClassName = "";
            body.floorCode = "";
            body.floorName = "";
            body.gisX = "";
            body.gisY = "";
            body.gisZ = "";
        }
        public Body body { get; set; }

        public class Body
        {
            public string alarmCode { get; set; }
            public string alarmName { get; set; }
            public string alarmClassCode { get; set; }
            public string alarmClassName { get; set; }
            public string alarmTypeCode { get; set; }
            public string alarmTypeName { get; set; }
            public string alarmLevelCode { get; set; }
            public string alarmLevelName { get; set; }
            public string alarmTime { get; set; }
            public string areaName { get; set; }
            public string alarmAddress { get; set; }
            public string alarmDescibe { get; set; }
            public string alarmStateCode { get; set; }
            public string alarmStateName { get; set; }
            public string alarmEquId { get; set; }
            public string alarmEquName { get; set; }
            public string equClassCode { get; set; }
            public string equClassName { get; set; }
            public string alarmSource { get; set; }
            public string gisX { get; set; }
            public string gisY { get; set; }
            public string gisZ { get; set; }
            public string floorCode { get; set; }
            public string floorName { get; set; }

        }

        public string toJson()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    public class MessageCommand
    {
        public Body body { get; set; }
        public Head meta { get; set; }
        public class Head
        {
            public string sender { get; set; }
            public string msgType { get; set; }
            public string eventType { get; set; }
            public string receiver { get; set; }
            public string sequence { get; set; }
            public string recvSequence { get; set; }
            public string sendTime { get; set; }
            public string recvTime { get; set; }
        }

        public class Body
        {
            public string alarmCode { get; set; }
            public string alarmName { get; set; }
            public string alarmClassCode { get; set; }
            public string alarmClassName { get; set; }
            public string alarmTypeCode { get; set; }
            public string alarmTypeName { get; set; }
            public string alarmLevelCode { get; set; }
            public string alarmLevelName { get; set; }
            public string alarmTime { get; set; }
            public string areaName { get; set; }
            public string alarmAddress { get; set; }
            public string alarmDescibe { get; set; }
            public string alarmStateCode { get; set; }
            public string alarmStateName { get; set; }
            public string alarmEquId { get; set; }
            public string alarmEquName { get; set; }
            public string equClassCode { get; set; }
            public string equClassName { get; set; }
            public string alarmSource { get; set; }
            public string gisX { get; set; }
            public string gisY { get; set; }
            public string gisZ { get; set; }
            public string floorCode { get; set; }
            public string floorName { get; set; }
            //关闭：0；打开：1
            public string openFlag { get;set;}
        }

        public static MessageCommand fromJson(string json)
        {
            return JsonConvert.DeserializeObject<MessageCommand>(json);
        }
    }

    public class MessageDeviceChange : MessageBase
    {
        const string msgType = "EQU_STATUS";
        const string eventType = "EQU_STATUS_UE";
        public MessageDeviceChange(IFiberDefenderAPUDevice devide,string timeStateId,string timeStateName)
        {
            meta.sender = sender;
            meta.msgType = msgType;
            meta.eventType = eventType;
            meta.receiver = receiver;
            meta.sequence = "";
            meta.recvSequence = "";
            meta.sendTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            meta.recvTime = "";
            body = new Body();
            body.createDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            body.equCode = devide.Name;
            body.timeStateId = timeStateId;
            body.timeStateName = timeStateName;
        }
        public MessageDeviceChange(AlarmEventArgs alarm, string timeStateId, string timeStateName)
        {
            meta.sender = sender;
            meta.msgType = msgType;
            meta.eventType = eventType;
            meta.receiver = receiver;
            meta.sequence = "";
            meta.recvSequence = "";
            meta.sendTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            meta.recvTime = "";
            body = new Body();
            body.createDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            body.equCode = alarm.Device.Name;
            body.timeStateId = timeStateId;
            body.timeStateName = timeStateName;
        }

        public Body body { get; set; }

        public class Body
        {
            public string equCode { get; set; }
            public string createDate { get; set; }
            public string timeStateId { get; set; }
            public string timeStateName { get; set; }
        }

        public string toJson()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
