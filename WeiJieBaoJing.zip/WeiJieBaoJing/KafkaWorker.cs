﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Confluent.Kafka;
using System.Diagnostics;
using System.Windows.Controls;
using WeiJieBaoJing;
using System.Windows.Forms;
using System.Threading;

public class KafkaWorker
{
    static string brokerList = ConfigWorker.GetConfigValue("kafkaUrl");
    static string messageTopicName = ConfigWorker.GetConfigValue("topicAlarm");
    static string deviceTopicName= ConfigWorker.GetConfigValue("topicDevice");
    static string commandTopicName = ConfigWorker.GetConfigValue("topicCommand");
    static string consumerGroupId = ConfigWorker.GetConfigValue("consumerGroupId");
    static IProducer<Null, string> producerAlarm=null;
    static IProducer<Null, string> producerDevice= null;
    static IConsumer<Ignore, string> consumerCommand = null;
    static ProducerConfig configAlarm = null;
    static ProducerConfig configDevice = null;
    static ConsumerConfig configCommand = null;

    public static async void sendAlarmMessage(string message)
    {
        if (configAlarm == null) { configAlarm = new ProducerConfig { BootstrapServers = brokerList }; }
        ControlTextSetter.setControlText(control, "正在向kafka发送alarm消息");
        //var config = new ProducerConfig { BootstrapServers = brokerList };
        try
        {
            if (producerAlarm == null) { producerAlarm = new ProducerBuilder<Null, string>(configAlarm).Build(); }
            //using (var producerAlarm = new ProducerBuilder<Null, string>(config).Build())
            {
                if (control != null)
                {
                    ControlTextSetter.setControlText(control, message);
                }
                //FileWorker.WriteTxt("alarm  "+message);
                var dr = await producerAlarm.ProduceAsync(messageTopicName, new Message<Null, string> { Value = message });
            }
        }
        catch (Exception e)
        {
            FileWorker.WriteTxt("alarm error  " + e.Message);
        }
    }
    public static async void sendDeviceMessage(string message)
    {
        if (configDevice == null) { configDevice = new ProducerConfig { BootstrapServers = brokerList }; }
        //var config = new ProducerConfig { BootstrapServers = brokerList };
        try
        {
            if (producerDevice == null) { producerDevice = new ProducerBuilder<Null, string>(configDevice).Build(); }
            //using (var producerDevice = new ProducerBuilder<Null, string>(config).Build())
            {
                if (control != null)
                {
                    //ControlTextSetter.setControlText(control, message);
                }
                //FileWorker.WriteTxt("device  " + message);
                var dr = await producerDevice.ProduceAsync(deviceTopicName, new Message<Null, string> { Value = message });
            }
        }
        catch (Exception e)
        {
            FileWorker.WriteTxt("device error  " + e.Message);
        }
    }

    public delegate void GetMessage(string message);
    public static event GetMessage OnGetMessage;

    public static void startGetMessage()
    {
        configCommand = new ConsumerConfig
        {
            GroupId = consumerGroupId,
            BootstrapServers = brokerList,
            AutoOffsetReset = AutoOffsetReset.Latest
        };
        using (consumerCommand = new ConsumerBuilder<Ignore, string>(configCommand).Build())
        {
            consumerCommand.Subscribe(commandTopicName);
            CancellationTokenSource cts = new CancellationTokenSource();
            //Console.CancelKeyPress += (_, e) => {
            //    e.Cancel = true; // prevent the process from terminating.
            //    cts.Cancel();
            //};

            try
            {
                while (true)
                {
                    try
                    {
                        var cr = consumerCommand.Consume(cts.Token);
                        OnGetMessage(cr.Value);
                        //Console.WriteLine($"Consumed message '{cr.Value}' at: '{cr.TopicPartitionOffset}'.");
                    }
                    catch (ConsumeException e)
                    {
                        MessageBox.Show($"Error occured: {e.Error.Reason}");
                    }
                }
            }
            catch (OperationCanceledException e)
            {
                // Ensure the consumer leaves the group cleanly and final offsets are committed.
                MessageBox.Show($"Error occured1: {e.Message}");
                consumerCommand.Close();
            }
        }
    }

    public static System.Windows.Forms.Control control = null;
    //public static void sendMessage(string message)
    //{
    //    if (control != null)
    //    {
    //        ControlTextSetter.setControlText(control, message);
    //    }
    //    FileWorker.WriteTxt(message);
    //    Debug.WriteLine(message);
    //}
}
