﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modbus.Device;
using System.Net;
using System.Net.Sockets;

namespace XiaoFangBaoJing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_readHodingRegister_Click(object sender, EventArgs e)
        {
            this.getData(this.txt_ip.Text.Trim(), (byte)this.num_slaveId.Value, (ushort)this.num_startAddress.Value, (ushort)this.num_pointNumber.Value, "HodingRegister");
        }
        private void btn_readInputRegister_Click(object sender, EventArgs e)
        {
            this.getData(this.txt_ip.Text.Trim(), (byte)this.num_slaveId.Value, (ushort)this.num_startAddress.Value, (ushort)this.num_pointNumber.Value, "InputRegister");
        }
        private void getData(string ip, byte slaveAddress, ushort startAddress, ushort numInputs, string functionType)
        {
            List<string> list = ip.Split(new string[]
            {
                "."
            }, StringSplitOptions.RemoveEmptyEntries).ToList<string>();
            byte[] array = new byte[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                array[i] = Convert.ToByte(list[i]);
            }
            IPAddress iPAddress = new IPAddress(array);
            using (TcpClient tcpClient = new TcpClient(iPAddress.ToString(), 502))
            {
                tcpClient.SendTimeout = 1;
                ModbusIpMaster modbusIpMaster = ModbusIpMaster.CreateIp(tcpClient);
                try
                {
                    if (!(functionType == "HodingRegister"))
                    {
                        if (functionType == "InputRegister")
                        {
                            ushort[] data = modbusIpMaster.ReadInputRegisters(slaveAddress, startAddress, numInputs);
                            this.showData(data, (int)numInputs);
                        }
                    }
                    else
                    {
                        ushort[] data = modbusIpMaster.ReadHoldingRegisters(slaveAddress, startAddress, numInputs);
                        this.showData(data, (int)numInputs);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void showData(ushort[] data, int numInputs)
        {
            for (int i = 0; i < numInputs; i++)
            {
                RichTextBox expr_0C = this.richTextBox1;
                expr_0C.Text += data[i].ToString();
            }
            RichTextBox expr_3C = this.richTextBox1;
            expr_3C.Text += Environment.NewLine;
        }
    }
}
